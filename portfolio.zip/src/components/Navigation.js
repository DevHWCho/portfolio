import React from 'react';
import { Link } from 'react-router-dom';
import 'styles/Navigation.scss';

function Navigation() {
  const onClick = () => {
    let activation = (list, i) => {
      for(let el of list){
        el.classList.remove('on');
      }
      list[i].classList.add('on');
    }
    const navBtn = document.querySelectorAll('.nav_btn');
    navBtn.forEach((btn, i)=>{
      btn.addEventListener('click',()=>{
        activation(navBtn, i);
      })
    })

  }

  return (
    <div className='nav' onClick={onClick}>
      <div className='nav_btn on'><Link to={'/about_me'}><p>ABOUT ME</p></Link></div>
      <div className='nav_btn'><Link to={'/project'}><p>PROJECT</p></Link></div>
      <div className='nav_btn'><Link to={'/other'}><p>OTHER</p></Link></div>
    </div>
  )
}

export default Navigation