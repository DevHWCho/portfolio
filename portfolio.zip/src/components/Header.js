import React from 'react';
import 'styles/Header.scss';

function Header() {
  return (
    <div className='header_container'> 
      <div className='header_text'>
        <h1>PORTFOLIO</h1>
        <p>BY HYUNWOONG CHO</p>
      </div>
      <div className='gnb'>
        <div className='gnb_container'>
          <ul>
            <li className='gnb_main'>INTRO
              <ul>
                <li className='gnb_sub'>COVER</li>
                <li className='gnb_sub'>INTRODUCTION</li>
              </ul>
            </li>
            <li className='gnb_main'>PROJECT
              <ul>
                <li className='gnb_sub'>DAVICH</li>
                <li className='gnb_sub'>SAMSUNG ELECTRO-MECHANICS</li>
                <li className='gnb_sub'>CJ ONE</li>
                <li className='gnb_sub'>MESSENGER</li>
                <li className='gnb_sub'>MOVIE APP</li>
              </ul>
            </li>
            <li className='gnb_main'>OTHER
              <ul>
                <li className='gnb_sub'>EMOJI</li>
                <li className='gnb_sub'>ANIMATION</li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default Header
