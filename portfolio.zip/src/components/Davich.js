import React from 'react'

function Davich() {
  return (
    <div className='davich_container'>
      davich...
    </div>
  )
}

export default Davich
