import React from 'react';
import 'styles/WorkExperience.scss';

function WorkExperience() {
  return (
    <div className='work_container'>
      work experience...
    </div>
  )
}

export default WorkExperience
