import React from 'react';
import 'styles/Main.scss';

function Main() {
  return (
    <div className='main_container'>
   
    </div>
  )
}

export default Main
